# Matriz via Excel — entrega (03/07/2026)

## Arquivos

| Arquivo | Ação | O quê |
|---|---|---|
| `matriz_loader.py` | **NOVO** | Lê/valida as abas "Matriz Editavel" e "Lista de Fundos Aprovados" |
| `fundos_config_v2.py` | alterado | + `aplicar_matriz(cfg)` / `restaurar_padrao()` / `FONTE_MATRIZ` (valores fixos viram fallback) |
| `app.py` | alterado | Upload da matriz no Passo 1, prévia + confirmação, validação que trava, indicador da matriz em uso |

Commits sugeridos (você faz o push — eu não tenho acesso ao repositório):
1. `feat: matriz_loader — leitura e validação da planilha da matriz`
2. `feat: fundos_config_v2 — override em tempo de execução (planilha > padrão)`
3. `feat: app — upload da matriz no Passo 1 com prévia, confirmação e trava`

## Comportamento (conforme decidido)

- **Sem planilha** → matriz padrão do sistema, com aviso visível "Matriz em uso:
  padrão do sistema". Nunca silencioso.
- **Planilha válida** → prévia (nº de perfis, nº de fundos, tabela de táticas)
  e botão "Confirmar e usar esta matriz". Só substitui o padrão após confirmar.
  Fica na sessão (várias propostas com um upload; recarregou a página, pede de novo).
- **Planilha inválida** → erros em português, **não avança** e **não** cai no
  padrão silenciosamente. Corrigiu, subiu de novo (o hash detecta o arquivo novo
  e exige nova confirmação).
- Validações que travam: soma da Tática ≠ 100% (tol. 0,1 p.p.) por perfil;
  fundo sem CNPJ; classe fora das 10 canônicas (nas duas abas); aba ausente.
- Avisos que não travam: fundo sem série no arquivo de cotas; casamento de nome
  por aproximação; perfil fora do padrão.
- Divisão de dados: **planilha** manda em fundos/CNPJ/classe, táticas, bandas,
  Objetivo e Volatilidade (meta, só exibição — se vazios, caem no padrão);
  **código/cadastro** manda em D+ de resgate, conversão, disponibilização e
  taxa adm (mesclados por CNPJ; fundo novo sem cadastro fica "a confirmar").
- Casamento fundo↔série: nome normalizado (maiúsculas, sem acento) com
  prefixo/continência — nomes truncados dos dois lados casam; ambiguidade vira
  aviso, nunca escolha silenciosa.

## Verificado contra os arquivos reais

- `Cópia_de_Matriz_atual_v2.xlsx`: 5 perfis lidos, todos somando 100%;
  13 fundos; bloco do Crescimento (que termina na linha 32 por ter PE/VC —
  fora da faixa 17–31 descrita) lido corretamente porque os blocos são
  ancorados pelo cabeçalho "Min|Base|Max|Tática|Var", não por linha fixa.
- Rótulos truncados/variantes casados: "Cred Corporati…", "Renda Variável L…",
  "Private Equity/V", "Ações"≡"Renda Variável", "MULTIMERCADOS",
  "RENDA FIXA INFLAÇÃO", "IMOBILIARIOS".
- `Series_01_07_2026…xlsx`: 13/13 fundos casados com série; disclaimers do
  export ignorados.
- Ponta a ponta: PDF e PPT gerados com a matriz do Excel ativa
  (ex.: vol-meta do Sofisticado = 7% da planilha, não os 6% do código).

## Limites conhecidos (para o handover)

1. **Trocar números e fundos: livre. Criar classe de ativo nova: precisa de
   desenvolvedor.** O vocabulário de 10 classes é fechado de propósito — classe
   desconhecida trava com mensagem clara em vez de sumir do PDF em silêncio.
2. O override muta o módulo `fundos_config_v2` (estado de processo). O app
   re-sincroniza a cada interação com a matriz da sessão, mas **duas pessoas
   usando o mesmo servidor no mesmo instante com matrizes diferentes** podem
   colidir num intervalo curto. Para o uso interno atual é aceitável; se o app
   virar multiusuário de verdade, o próximo passo é passar a config por
   parâmetro aos geradores em vez de via módulo.
3. A prévia mostra as táticas; bandas e metas são lidas e usadas, mas não
   aparecem na prévia (dá para acrescentar se o comitê quiser conferir).
